

def func():
    print('Я не понимаю, что делаю')



if __name__ == "__func__":
    func()
