# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hw_19']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['do_something = hw_19.main:func']}

setup_kwargs = {
    'name': 'hw-19',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Dima Saushkin',
    'author_email': 'saushkin.reg@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
